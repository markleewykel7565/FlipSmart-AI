# FlipSmart AI v2

## Features
- Real OpenAI analysis endpoint
- Optional image upload sent to the AI model
- Structured resale report
- Stripe subscription checkout endpoint

## Run
1. Install Node.js 18+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add OPENAI_API_KEY.
5. For payments, add STRIPE_SECRET_KEY, STRIPE_PRICE_ID, and APP_URL.
6. Run `npm start`.
7. Visit http://localhost:3000

## Important
The app does not automatically retrieve verified sold listings. Add a properly authorized marketplace-data provider before marketing price estimates as market-verified.
